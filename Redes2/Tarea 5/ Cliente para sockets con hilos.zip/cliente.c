#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <netinet/in.h>
#include <resolv.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

#define PUERTO 12345
#define DIRECCION "127.0.0.1"
#define TAMBUFER 1024

int main(int argv, char** argc)
{
	struct sockaddr_in my_addr;
    char buffer[TAMBUFER];
    int bytecount;

    int hsock;
    int * p_int;
    int err;
    // se crea el socket
    hsock = socket(AF_INET, SOCK_STREAM, 0);

    if (hsock == -1)
    {
    	printf("Error. %d\n",errno);
    	exit(-1);
    }
    //tamaño para el socket 
    p_int = (int*)malloc(sizeof(int));
    *p_int = 1;

    // se configura el socket 
    if ((setsockopt(hsock,SOL_SOCKET,SO_REUSEADDR, (char*)p_int,sizeof(int ))==-1) || (setsockopt(hsock,SOL_SOCKET,SO_KEEPALIVE, (char*)p_int,sizeof(int)) == -1 ))
    {
    	printf("Error de configuraciones.%d\n",errno);
    	free(p_int);
    	exit(-1);
    }

    free(p_int);

    my_addr.sin_family = AF_INET; // familia  de protocolos
    my_addr.sin_port = htons(PUERTO); // se asigna el puerto 
    memset(&(my_addr.sin_zero),0,8); // se rellena la estructura con 0
    my_addr.sin_addr.s_addr = inet_addr(DIRECCION); // se agrega la direccion 

    // se realiza la coneccion 
	if ( connect(hsock,(struct sockaddr*)&my_addr,sizeof(my_addr)) == -1 )
	{
		if ((err= errno) != EINPROGRESS)
		{
			fprintf(stderr, "Error de conexión %d\n",errno );
			exit(-1);
		}
	}    

	memset(buffer,'\0',TAMBUFER);// se limpia el buufer
	printf("---> Conectado ");

	while(1)
    {
        read(hsock, buffer, sizeof(buffer)); // se lee lo que se encuentra en el socket 
        printf("%s\n",buffer); // se imprime 
        sleep(4); 
    }


	close(hsock);
return 0;
}