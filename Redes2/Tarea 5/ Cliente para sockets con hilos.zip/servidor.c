#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
//lpthread
#define PUERTO  12345
#define PROCESOS 10
#define TAMBUFER 1024
#define DIRECCION "127.0.0.1"

void *talker( void *d ) 
{
	int i = 0;
	char buf[TAMBUFER];
	int fd;
	fd = (int)d;
	while( 1 ) 
	{
        sprintf( buf, "%d\n", i++ );
        write( fd, buf, strlen( buf )+1 );
        sleep(4);
	}
}

int main() 
{
	int ss,s1,s2,n;
	fd_set sockfds;
	struct timeval tv;
	struct sockaddr_in my_addr;
	struct sockaddr_in socks[PROCESOS];
	pthread_t thread[PROCESOS];
	int i=1;

	ss = socket( PF_INET, SOCK_STREAM, 0 ); // se crea el socket
	my_addr.sin_family = AF_INET; // familia de protocolos
	my_addr.sin_port = htons(PUERTO); // se asigna el peurto 
	memset( &(my_addr.sin_zero), '\0', 8 ); // Limpia la memoria
//	bzero(&(my_addr.sin_zero),8); diferencia -->
	my_addr.sin_addr.s_addr = inet_addr(DIRECCION);
	
	// se abre el socket para varias conexiones 
	setsockopt( ss, SOL_SOCKET, SO_REUSEADDR, &i, sizeof(int) ); 
	
	
	bind( ss, (struct sockaddr* )&my_addr, sizeof( struct sockaddr ) );// asociamos el socket con el puerto 
	listen( ss, PROCESOS); // estamos a espera de la coneccion

	n = sizeof( struct sockaddr_in );
	i=0;
	printf("Servidor corriendo ...\n");
	while( 1 ) 
	{
        s1 = accept( ss, (struct sockaddr *)&socks[1], &n );
        printf("Conexión de un cliente...\n");
        pthread_create( &(thread[i++]), NULL, talker, (void *)s1 );
	}
return(0);
}
