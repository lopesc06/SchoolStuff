import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ServidorWeb
{
	public static final int PUERTO=8000;
	ServerSocket ss;
        int  corePoolSize  =    1;
        int  maxPoolSize   =   1;
        long keepAliveTime = 5000;
	
       
        
		class Manejador extends Thread
		{
			protected Socket socket;
			protected PrintWriter pw;
			protected BufferedOutputStream bos;
			protected BufferedReader br;
			protected String FileName;
			
                    
			public Manejador(Socket _socket) throws Exception
			{
				this.socket=_socket;
			}
			@Override
                     
                       /* ExecutorService threadPoolExecutor = new ThreadPoolExecutor(corePoolSize,maxPoolSize,keepAliveTime,
                        TimeUnit.MILLISECONDS,new LinkedBlockingQueue<Runnable>());
                        threadPoolExecutor.*/
                        
			public void run()
			{
				try{
					
                                        BufferedInputStream bis=new BufferedInputStream(socket.getInputStream());
					bos=new BufferedOutputStream(socket.getOutputStream());
					pw=new PrintWriter(new OutputStreamWriter(bos));
					byte[] buf = new byte[2000];
                                        bis.read(buf);
                                        String line= new String(buf);
                                      
					if(line==null)
					{
                                            pw.print("<html><head><title>Servidor WEB");
                                            pw.print("</title><body bgcolor=\"#AACCFF\"<br>Linea Vacia</br>");
                                            pw.print("</body></html>");
                                            socket.close();
                                            return;
					}
					if(line.indexOf("?")==-1 && line.toUpperCase().startsWith("GET"))
					{
                                            getArch(line); //Le quita el GET / al archivo y lo guarda en FileName.
                                            if(FileName.compareTo("")==0)
                                            {
						SendA("index.htm");//Si sólo escribe 127.0.0.1 sin el /index.html
                                            }
                                            else
                                            {
						SendA(FileName);//Envía el archivo al cliente para que lo pueda visualizar.
                                            }
                                            System.out.println(FileName);	
					}
                                        else if(line.toUpperCase().startsWith("GET"))
					{ 
                                            System.out.println("Es GET");
                                            StringTokenizer tokens=new StringTokenizer(line," ");
                                            tokens.nextToken();
                                            String line1=tokens.nextToken();
                                            if(line1.contains("?") && line1.contains("&")) {
                                                String result = line1.replaceAll("[/?]","");
                                                StringTokenizer yeah=new StringTokenizer(result,"&");
                                                String line2=yeah.nextToken();
                                                String line3=yeah.nextToken();
                                                String line4=yeah.nextToken();
                                                String line5=yeah.nextToken();
                                                StringTokenizer yeah1=new StringTokenizer(line2,"=");
                                                StringTokenizer yeah2=new StringTokenizer(line3,"=");
                                                StringTokenizer yeah3=new StringTokenizer(line4,"=");
                                                StringTokenizer yeah4=new StringTokenizer(line5,"=");
                                                yeah1.nextToken();
                                                line2=yeah1.nextToken();
                                                yeah2.nextToken();
                                                line3=yeah2.nextToken();
                                                yeah3.nextToken();
                                                line4=yeah3.nextToken();
                                                yeah4.nextToken();
                                                line5=yeah4.nextToken();
                                                String pagina="";
                                                String aux="";
                                                aux=aux+"<html><head><title>SERVIDOR WEB";
                                                aux=aux+"</title></head><body bgcolor=\"#AACCFF\"><center><h1><br>Parametros Obtenidos..</br></h1>";
                                                aux=aux+"<h3><b>"+"<br>"+line2+"<br>"+line3+"<br>"+line4+"<br>"+line5+"</b></h3>";
                                                aux=aux+"</center></body></html>";
                                                int sizeofpage=aux.length();
                                                pagina= pagina+"HTTP/1.0 200 ok\n";
                                                pagina = pagina +"Server: Gerardo Server/1.0 \n";
                                                pagina = pagina +"Date: " + new Date()+" \n";
                                                pagina = pagina +"Content-Type: text/html \n";
                                                pagina = pagina +"Content-Length: "+sizeofpage+" \n";
                                                pagina = pagina +"\n";
                                                bos.write(pagina.getBytes());
                                                bos.flush();
                                                bos.write(aux.getBytes());
                                                bos.flush();
                                            }
                                            else if(line1.contains("?")){
                                                System.out.println("Es GET 1");
						StringTokenizer tokens_0=new StringTokenizer(line,"?");
						String req_a=tokens_0.nextToken();
						String req=tokens_0.nextToken();
                                                StringTokenizer otrotoken= new StringTokenizer(req,"\n");
                                                String needed=otrotoken.nextToken();
                                                StringTokenizer otrotoken2= new StringTokenizer(needed,"=");
                                                String name=otrotoken2.nextToken();
                                                String name1=otrotoken2.nextToken();
                                                //System.out.println("aqui"+name1);
                                                StringTokenizer otrotoken3= new StringTokenizer(name1," ");
                                                String elrecurso=otrotoken3.nextToken();
                                                SendA(elrecurso);
                                            }
                                            else if(line1.contains("/" )){
                                                System.out.println("Es GET 2");
                                                StringTokenizer tokens_2=new StringTokenizer(line,"/");
						tokens_2.nextToken();
						String b=tokens_2.nextToken();
                                                StringTokenizer tokens2=new StringTokenizer(b," ");
                                                String c=tokens2.nextToken();
                                                SendA(c);
                                               }
						
					}
                                        else if(line.toUpperCase().startsWith("POST")){
                                            
                                            System.out.println("Es post");//dejarla no hay pex
                                            StringTokenizer tokens=new StringTokenizer(line,"\n");
                                            String s="";
                                            int i=0;
                                            
                                            while(tokens.hasMoreTokens()){
                                                if(i==13){
                                                    s=tokens.nextToken();
                                                }
                                                else{
                                                    tokens.nextToken();
                                                    i++;
                                                }
                                            }
                                            if(s.contains("&")){
                                                StringTokenizer real=new StringTokenizer(s,"&");
                                               // System.out.println(real);
                                                String data1=real.nextToken();
                                               // System.out.println(data1);
                                                StringTokenizer other1=new StringTokenizer(data1,"=");
                                               // System.out.println(other1);
                                                other1.nextToken();
                                                data1=other1.nextToken();
                                                //System.out.println(data1);
                                                String data2=real.nextToken();
                                                System.out.println(data2);
                                                StringTokenizer other2=new StringTokenizer(data2,"=");
                                                System.out.println(other2);
                                                other2.nextToken();
                                                data2=other2.nextToken();
                                                System.out.println(data2);
                                                String data3=real.nextToken();
                                                System.out.println(data3);
                                                StringTokenizer other3=new StringTokenizer(data3,"=");
                                                System.out.println(other3);
                                                other3.nextToken();
                                                data3=other3.nextToken();
                                                System.out.println(data3);
                                                String data4=real.nextToken();
                                                System.out.println(data4);
                                                StringTokenizer other4=new StringTokenizer(data4,"=");
                                                System.out.println(other4);
                                                other4.nextToken();
                                                data4=other4.nextToken();
                                                System.out.println(data4);
                                                //////
                                                String pagina="";
                                                String aux="";
                                                   
                                                aux=aux+"<html><head><title>SERVIDOR WEB";
                                                aux=aux+"</title></head><body bgcolor=\"#AACCFF\"><center><h1><br>Parametros Obtenidos..</br></h1>";
                                                aux=aux+"<h3><b>"+"<br>"+data1+"<br>"+data2+"<br>"+data3+"<br>"+data4+"</b></h3>";
                                                aux=aux+"</center></body></html>";
                                                int sizeofpage=aux.length();
                                                pagina= pagina+"HTTP/1.0 200 ok\n";
                                                pagina = pagina +"Server: Gerardo Server/1.0 \n";
                                                pagina = pagina +"Date: " + new Date()+" \n";
                                                pagina = pagina +"Content-Type: text/html \n";
                                                pagina = pagina +"Content-Length: "+sizeofpage+" \n";
                                                pagina = pagina +"\n";
                                                  
                                               /* bos.write(pagina.getBytes());
                                                bos.flush();*/
                                                bos.write(aux.getBytes());
                                                bos.flush();
                                                System.out.println(pagina);
                                            }
                                            else{
                                            
                                                StringTokenizer nneeded= new StringTokenizer(s,"=");
                                                nneeded.nextToken();
                                                String elrequest = nneeded.nextToken();
                                                StringReader reader=new StringReader(elrequest);

                                                int j;
                                                String elrequest2="";
                                                String c;
                                                for(j=0;i<elrequest.length();j++) {
                                                    if(Character.isLetter(elrequest.charAt(j)) || (elrequest.charAt(j))=='.')
                                                        elrequest2=elrequest2+elrequest.charAt(j);
                                                    else
                                                     break;
                                                }
                                                SendA(elrequest2);
                                            }
                                        }
                                        else if(line.toUpperCase().startsWith("HEAD")){
                                            System.out.println("Es head");
                                            StringTokenizer forhead= new StringTokenizer(line," ");
                                            forhead.nextToken();
                                            String file_requested=forhead.nextToken();
                                            file_requested=file_requested.replaceAll("/", "");
                                            File file = new File(file_requested);
                                            try{
                                                FileInputStream fis = new FileInputStream(file);
                                                System.out.println(fis);
                                                byte[] data = new byte[(int) file.length()];
                                                fis.read(data);
                                                fis.close();
                                                String content = new String(data, "UTF-8");
                                                int file_size=content.length();
                                                String pagina="";
                                                pagina= pagina+"HTTP/1.0 200 Holi :3\n";
                                                pagina = pagina +"Server: Gerardo Server/1.0 \n";
                                                pagina = pagina +"Date: " + new Date()+" \n";
                                                pagina = pagina +"Content-Type: text/html \n";
                                                pagina = pagina +"Content-Length: "+file_size+" \n";
                                                pagina = pagina +"\n";
                                                bos.write(pagina.getBytes());
                                                bos.flush();
                                            }catch(Exception e){
                                                String the404="";
                                                the404=the404+"<!DOCTYPE html>";
                                                the404=the404+"<html>";
                                                the404=the404+"<head>";
                                                the404=the404+"<meta http-equiv='Content-Type' content='text/html;' />";
                                                the404=the404+"<title>ERROR 404 not FOUND!</title>";
                                                the404=the404+"</head>";
                                                the404=the404+"<body>";
                                                the404=the404+"<h1>ERROR 404 the resource was not found <h1>";
                                                the404=the404+"<br>";
                                                the404=the404+"<h2> Shit happens :/ <h2>";
                                                the404=the404+"</body>";
                                                the404=the404+"</html>";
                                              
                                                int file_size=the404.length();
                                                System.out.println("LLegue aqui :yay");
                                                String pagina="";
                                                pagina= pagina+"HTTP/1.0 404 Not_Found\n";
                                                pagina = pagina +"Server: Gerardo Server/1.0 \n";
                                                pagina = pagina +"Date: " + new Date()+" \n";
                                                pagina = pagina +"Content-Type: text/html \n";
                                                pagina = pagina +"Content-Length: "+file_size+" \n";
                                                pagina = pagina +"\n";
                                                bos.write(pagina.getBytes());
                                                bos.flush();
                                                bos.write(the404.getBytes());
                                                bos.flush();      
                                            }        
                                        }
					else
					{
                                            String the501="";
                                            the501=the501+"<!DOCTYPE html>";
                                            the501=the501+"<html>";
                                            the501=the501+"<head>";
                                            the501=the501+"<meta http-equiv='Content-Type' content='text/html;' />";
                                            the501=the501+"<title>ERROR 501 not FOUND!</title>";
                                            the501=the501+"</head>";
                                            the501=the501+"<body>";
                                            the501=the501+"<h1>ERROR 501 this was never implemented :P <h1>";
                                            the501=the501+"<br>";
                                            the501=the501+"<h2> Shit happens :/ <h2>";
                                            the501=the501+"</body>";
                                            the501=the501+"</html>";
                                            int file_size=the501.length();
                                            System.out.println("LLegue aqui :yay el del 501");
                                            String pagina="";
                                            pagina= pagina+"HTTP/1.0 501 Not_Implemented\n";
                                            pagina = pagina +"Server: Gerardo Server/1.0 \n";
                                            pagina = pagina +"Date: " + new Date()+" \n";
                                            pagina = pagina +"Content-Type: text/html \n";
                                            pagina = pagina +"Content-Length: "+file_size+" \n";
                                            pagina = pagina +"\n";
                                            bos.write(pagina.getBytes());
                                            bos.flush();
                                            bos.write(the501.getBytes());
                                            bos.flush();
					}
					pw.flush();
					bos.flush();
                                    }
                                    catch(Exception e)
                                    {
					e.printStackTrace();
                                    }
                                    try{
					socket.close();
                                    }
                                    catch(Exception e)
                                    {
					e.printStackTrace();
                                    }
			}
			
			public void getArch(String line)
			{
                            int i;
                            int f;
                            if(line.toUpperCase().startsWith("GET"))
                            {
				i=line.indexOf("/");
				f=line.indexOf(" ",i);
				FileName=line.substring(i+1,f);
                            }
                            else if(line.toUpperCase().startsWith("GET"))//edit
                            {
				i=line.indexOf("/");
				f=line.indexOf(" ",i);
				FileName=line.substring(i+1,f);
                            }
			}
			public void SendA(String fileName,Socket sc)
			{
                            int fSize = 0;
                            byte[] buffer = new byte[4096];
                            try{
				DataOutputStream out =new DataOutputStream(sc.getOutputStream());
				FileInputStream f = new FileInputStream(fileName);
				int x = 0;
				while((x = f.read(buffer))>0)
				{
                                    out.write(buffer,0,x);
				}
                                    out.flush();
                                    f.close();
                            }catch(FileNotFoundException e){
					//msg.printErr("Transaction::sendResponse():1", "El archivo no existe: " + fileName);
                            }catch(IOException e){
		//			System.out.println(e.getMessage());
					//msg.printErr("Transaction::sendResponse():2", "Error en la lectura del archivo: " + fileName);
                            }	
			}
			public void SendA(String arg) 
			{
                            try{
                                int b_leidos=0;
                                BufferedInputStream bis2=new BufferedInputStream(new FileInputStream(arg));
                                byte[] buf=new byte[1024];
                                int tam_bloque=0;
                                if(bis2.available()>=1024)
                                {
                                   tam_bloque=1024;
                                }
                                else
                                {
                                   bis2.available();
                                }
                                int tam_archivo=bis2.available();
		     /***********************************************/
				String sb = "";
				sb = sb+"HTTP/1.0 200 ok\n";
			        sb = sb +"Server: Benja Server/1.0 \n";
				sb = sb +"Date: " + new Date()+" \n";
				sb = sb +"Content-Type: text/html \n";
				sb = sb +"Content-Length: "+tam_archivo+" \n";
				sb = sb +"\n";
				bos.write(sb.getBytes());
				bos.flush();
                                while((b_leidos=bis2.read(buf,0,buf.length))!=-1)
                                {
                                   bos.write(buf,0,b_leidos);
                                }
                                bos.flush();
                                bis2.close();
                            }
                            catch(Exception e)
                            {
                                try{
                                    String the404="";
                                    the404=the404+"<!DOCTYPE html>";
                                    the404=the404+"<html>";
                                    the404=the404+"<head>";
                                    the404=the404+"<meta http-equiv='Content-Type' content='text/html;' />";
                                    the404=the404+"<title>ERROR 404 not FOUND!</title>";
                                    the404=the404+"</head>";
                                    the404=the404+"<body>";
                                    the404=the404+"<h1>ERROR 404 the resource was not found <h1>";
                                    the404=the404+"<br>";
                                    the404=the404+"<h2> Shit happens :/ <h2>";
                                    the404=the404+"</body>";
                                    the404=the404+"</html>";
                                              
                                    int file_size=the404.length();
                                    System.out.println("LLegue aqui :yay");
                                    String pagina="";
                                    pagina= pagina+"HTTP/1.0 404 Not_Found\n";
                                    pagina = pagina +"Server: Benja Server/1.0 \n";
                                    pagina = pagina +"Date: " + new Date()+" \n";
                                    pagina = pagina +"Content-Type: text/html \n";
                                    pagina = pagina +"Content-Length: "+file_size+" \n";
                                    pagina = pagina +"\n";
                                    bos.write(pagina.getBytes());
                                    bos.flush();
                                    bos.write(the404.getBytes());
                                    bos.flush();
                                    }
                                catch(Exception f){
                                    e.printStackTrace();
                                    System.out.println("Now you fucked it up!");
                                }
                            }
			}
		}
		public ServidorWeb() throws Exception
		{
                    System.out.println("Iniciando Servidor.......");
                    this.ss=new ServerSocket(PUERTO);
                    System.out.println("Servidor iniciado:---OK");
                    System.out.println("Esperando por Cliente....");
                   
                    for(;;)//Meter la alberca de hilos.ThreadPoolExecutor.
                    {
                        Socket accept=ss.accept();
                         ExecutorService threadPoolExecutor = new ThreadPoolExecutor(corePoolSize,maxPoolSize,keepAliveTime,
                        TimeUnit.MILLISECONDS,new LinkedBlockingQueue<Runnable>());
                        threadPoolExecutor.execute(new Manejador(accept));

                    }
		}
		
		public static void main(String[] args) throws Exception{
                    ServidorWeb sWEB=new ServidorWeb();
		}
	
}