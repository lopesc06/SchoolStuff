
package p2;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.*;
import java.util.*;
 


public class FileO {
    
   /* public static void main(String args[]){
        FileO f=new FileO();
        f.ReadFile();
    }*/
    
    private BufferedReader br;
    private String line;
    private String [] parts;
    private Product p;
    private ArrayList<Product> prods=new ArrayList();
    private File f;
   
    protected ArrayList<Product> ReadFile(){
        try {
            br = new BufferedReader(new FileReader("src\\p2\\images\\productos.txt"));
            while((line=br.readLine())!=null){
                parts=line.split(",");
                p=new Product();
                p.setCode(parts[0]);
                p.setName(parts[1]);
                p.setPrice(Float.parseFloat(parts[2].trim()));
                p.setStock(Integer.parseInt(parts[3].trim()));
                p.setI(parts[4].trim()+".jpg");
                prods.add(p);
                line=null;
            }
            br.close();
       } catch (FileNotFoundException ex) {
            System.out.println(ex);
        }catch (IOException e) {
            System.out.println(e);
            
        }
        return prods;
    } 
    
    public void RefreshF(ArrayList<Product> cart){
         try {
                FileOutputStream fileOut;
                for(Product pr:cart){
                    br = new BufferedReader(new FileReader("src\\p2\\images\\productos.txt"));
                    fileOut = new FileOutputStream("src\\p2\\images\\productos2.txt");
                    while((line=br.readLine())!=null){
                        parts=line.split(",");
                        if(parts[0].equals(pr.getCode())){
                            line=pr.getCode()+","+pr.getName()+","+String.valueOf(pr.getPrice())+","
                                    +String.valueOf(pr.getStock()-pr.getQuant_cart())+","
                                    +pr.getI().substring(0,pr.getI().indexOf("."))+"\n";
                            fileOut.write(line.getBytes());
                        }    
                        else 
                            fileOut.write(line.concat("\n").getBytes());
                    }
                    fileOut.close();
                    br.close();
                    File f1= new File("src\\p2\\images\\productos.txt");
                    f1.delete();
                    File f2= new File("src\\p2\\images\\productos2.txt");
                    f2.renameTo(new File("src\\p2\\images\\productos.txt"));
                    
                }
        } catch (FileNotFoundException ex) { System.out.println(ex);}
          catch (IOException e) { System.out.println(e); }
         Ticket(cart);
    }
    
    private void Ticket(ArrayList<Product> cart){
         Document document = new Document();
      try
      {
         float total=0;
         PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Ticket.pdf"));
         document.open();
         
         for(Product a:cart){
             total=total+a.getPrice()*a.getQuant_cart();
             document.add(new Paragraph(a.getName()+" Cantidad:"+String.valueOf(a.getQuant_cart())+" Costo:$"+String.valueOf(a.getPrice())+"  Subotal:$"
                            +String.valueOf(a.getPrice()*a.getQuant_cart())));
         }
         document.add(new Paragraph("------------------------------------------------------------------->Total:$"+total));
         document.close();
         writer.close();
      } catch (DocumentException e)
            {e.printStackTrace();} 
      catch (FileNotFoundException e)
            {e.printStackTrace();}
    }
}
