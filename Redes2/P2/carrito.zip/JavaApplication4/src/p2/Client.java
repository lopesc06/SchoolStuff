
package p2;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Client {
    private String host= "127.0.0.1";
    private int pto = 9090;
    private ObjectOutputStream oos = null;
    private ObjectInputStream ois = null;
    private ArrayList<Product> prods=new ArrayList();
    private Socket cl;
    
    public  ArrayList<Product> GetProducts(){
        try{
            cl = new Socket(host,pto);
            System.out.println("Conexión establecida...");
            ois = new ObjectInputStream(cl.getInputStream());
            oos= new ObjectOutputStream(cl.getOutputStream());
            prods = (ArrayList<Product>)ois.readObject();
            
            //for(Product a:prods)
              // System.out.println(a.getCode()+a.getName());
            
        }catch(Exception e){ System.err.println(e);}//catch
        return prods; 
    }
    
      public  void sendProducts(ArrayList<Product> cart){
        try{
            oos.writeObject(cart);
            oos.flush();            
        }catch(Exception e){ System.err.println(e);}//catch
        
    }

}
