/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

import java.io.Serializable;


public class Product implements Serializable{
    
    private String code;
    private int stock;
    private String name;
    private float price;
    private String I;
    private int Quant_cart;

    public int getQuant_cart() {
        return Quant_cart;
    }

    public void setQuant_cart(int Quant_cart) {
        this.Quant_cart = Quant_cart;
    }
    

    public String getI() {
        return I;
    }

    public void setI(String I) {
        this.I = I;
    }

    
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
    
    
}
