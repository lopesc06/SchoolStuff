/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
/**
 *
 * @author Arturo Escutia
 */
public class Server {
    
        private static ObjectOutputStream oos = null;
        private static ObjectInputStream ois= null;
        private static ArrayList<Product> prods=new ArrayList();
        private static FileO f=new FileO();

              
    public static void main(String args[]){
       
      try{
            ServerSocket s = new ServerSocket(9090);
            System.out.println("Servicio iniciado... Esperando cliente");
            for(;;){
                Socket cl= s.accept();
                System.out.println("Cliente conectado desde "+cl.getInetAddress()+":"+cl.getPort());
                oos= new ObjectOutputStream(cl.getOutputStream());
                ois = new ObjectInputStream(cl.getInputStream());
                prods=f.ReadFile();
                oos.writeObject(prods);
                oos.flush();
                prods.clear();
                prods=(ArrayList<Product>)ois.readObject();
               // for(Product a:prods)
                //    System.out.println(a.getCode()+a.getName());
                f.RefreshF(prods);
                
            }//for
        }catch(Exception e){  e.printStackTrace();  }//catch   
      
    }
}
