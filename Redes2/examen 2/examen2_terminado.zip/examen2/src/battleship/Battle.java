package battleship;

import java.io.Serializable;
import java.util.Scanner;
import java.util.Random;

public class Battle implements Serializable{

	private transient Scanner in;
	private boardPiece[][] pboard = {   {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},};
	
	private boardPiece[][] eboard = {   {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},
                                            {new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece(),new boardPiece()},};
	private char turn = 'X';
        private boolean win = false;
	private int count = 0;
	private Random generator = new Random(System.currentTimeMillis());
	private ship sub = new ship(1);
	private ship destroyer = new ship(2);
	private ship battleship = new ship(3);
	private ship esub = new ship(1);
	private ship edestroyer = new ship(2);
	private ship ebattleship = new ship(3);
	private AIplay AI = new AIplay();

       
        public boolean isWin() {
            return win;
        }

	public void printBoard1(){
		System.out.println("           ENEMY                                                                   PLAYER 0");
		System.out.println("   A   B   C   D   E   F   G   H   I   J   K   L   M   N   O          A   B   C   D   E   F   G   H   I   J   K   L   M   N   O");
		for(int x=0; x<15; x++){
			System.out.print((char)(65+x) + " ");
			for(int y=0; y<15; y++){
                                if(!eboard[x][y].piece.equals("_@_|"))
                                    System.out.print(eboard[x][y].piece);
                                else
                                    System.out.print("___|");
			}
			System.out.print("     ");
			System.out.print((char)(65+x) + " ");
			for(int z=0; z<15; z++){
				System.out.print(pboard[x][z].piece);
			}
			System.out.println();
		}
	}
        
        public void printBoard2(){
		System.out.println("           Player 1                                                                   Enemy");
		System.out.println("   A   B   C   D   E   F   G   H   I   J   K   L   M   N   O          A   B   C   D   E   F   G   H   I   J   K   L   M   N   O");
		for(int x=0; x<15; x++){
			System.out.print((char)(65+x) + " ");
			for(int y=0; y<15; y++){
                                System.out.print(eboard[x][y].piece);
                                
			}
			System.out.print("     ");
			System.out.print((char)(65+x) + " ");
			for(int z=0; z<15; z++){
                            if(!pboard[x][z].piece.equals("_@_|"))
				System.out.print(pboard[x][z].piece);
                             else
                                    System.out.print("___|");
			}
			System.out.println();
		}
	}
        
	public void place1(){
		System.out.println();
		String input;
		boolean start = false;
		in=new Scanner(System.in);
		while(!start){
			input = in.nextLine();
			
			if(input.length() == 1){
				if(input.charAt(0) == 'S'){
					if(battleship.placed && destroyer.placed && sub.placed)
						start = true;
					else
						System.out.println("You need to place all of your ships.");
				}
				else{
					System.out.println("Invalid Input. Try Again.");
				}
			}
			else if(input.length() >= 6){
				if(((int)input.charAt(0)-48) >= 4){
					System.out.println("Invalid Ship Type. Try Again.");
				}
				else if(((int)input.charAt(2)-65) >= 15){
					System.out.println("Invalid Row. Try Again.");
				}
				else if(((int)input.charAt(3)-65) >= 15){
					System.out.println("Invalid Column. Try Again.");
				}
				else if((int)input.charAt(5) != 72 && (int)input.charAt(5) != 86){
					System.out.println("Invalid Orientation. Try Again.");
				}
				else{   //Valid Input
					if((int)input.charAt(5) == 72 && (((int)input.charAt(0)-48) + 1) > (15 - ((int)input.charAt(3)-65))){
						System.out.println("Invalid Horizontal Placement. Not enough room.");
					}
					else if((int)input.charAt(5) == 86 && (((int)input.charAt(0)-48) + 1) > (15 - ((int)input.charAt(2) - 64))){
						System.out.println("Invalid Vertical Placement. Not enough room.");
					}
					else{ //Valid Placement, except for overlap
						if(((int)input.charAt(0)-48) == 1){
							placeBoard1(input.charAt(5), sub, input.substring(2,4));
						}
						else if(((int)input.charAt(0)-48) == 2){
							placeBoard1(input.charAt(5), destroyer, input.substring(2,4));
						}
						else{
							placeBoard1(input.charAt(5), battleship, input.substring(2,4));
						}
					}
				}
			}
			else{
				System.out.println("Invalid Input. Try Again.");
			}
		}
	}
	
	public void place2(){
            
		System.out.println();
		String input;
		boolean start = false;
		in=new Scanner(System.in);
		while(!start){
			input = in.nextLine();
			
			if(input.length() == 1){
				if(input.charAt(0) == 'S'){
					if(battleship.placed && destroyer.placed && sub.placed)
						start = true;
					else
						System.out.println("You need to place all of your ships.");
				}
				else{
					System.out.println("Invalid Input. Try Again.");
				}
			}
			else if(input.length() >= 6){
				if(((int)input.charAt(0)-48) >= 4){
					System.out.println("Invalid Ship Type. Try Again.");
				}
				else if(((int)input.charAt(2)-65) >= 15){
					System.out.println("Invalid Row. Try Again.");
				}
				else if(((int)input.charAt(3)-65) >= 15){
					System.out.println("Invalid Column. Try Again.");
				}
				else if((int)input.charAt(5) != 72 && (int)input.charAt(5) != 86){
					System.out.println("Invalid Orientation. Try Again.");
				}
				else{   //Valid Input
					if((int)input.charAt(5) == 72 && (((int)input.charAt(0)-48) + 1) > (15 - ((int)input.charAt(3)-65))){
						System.out.println("Invalid Horizontal Placement. Not enough room.");
					}
					else if((int)input.charAt(5) == 86 && (((int)input.charAt(0)-48) + 1) > (15 - ((int)input.charAt(2) - 64))){
						System.out.println("Invalid Vertical Placement. Not enough room.");
					}
					else{ //Valid Placement, except for overlap
						if(((int)input.charAt(0)-48) == 1){
							placeBoard2(input.charAt(5), sub, input.substring(2,4));
						}
						else if(((int)input.charAt(0)-48) == 2){
							placeBoard2(input.charAt(5), destroyer, input.substring(2,4));
						}
						else{
							placeBoard2(input.charAt(5), battleship, input.substring(2,4));
						}
					}
				}
			}
			else{
				System.out.println("Invalid Input. Try Again.");
			}
		}
	}
	
	public void placeBoard1(char layout, ship current, String locale){
		
		boolean overlap = false;
		
		if(layout == 'H'){
			for(int x=((int)locale.charAt(1)-65);x<((int)locale.charAt(1)-65)+(current.type + 1);x++){
				if(pboard[((int)locale.charAt(0)-65)][x].type != current.type &&
				   pboard[((int)locale.charAt(0)-65)][x].used == true)
					overlap = true;
			}
		}
		else{  //layout == 'V'
			for(int x=((int)locale.charAt(0)-65);x<((int)locale.charAt(0)-65)+(current.type + 1);x++){
				if(pboard[x][((int)locale.charAt(1)-65)].type != current.type &&
				   pboard[x][((int)locale.charAt(1)-65)].used == true)
					overlap = true;
			}
		}
		if(!overlap){ //If ships don't overlap
			if(current.placed){
				if(current.orientation == 'H'){
					for(int x=((int)current.location.charAt(1)-65);x<((int)current.location.charAt(1)-65)+(current.type + 1);x++){
						pboard[((int)current.location.charAt(0)-65)][x].piece = "___|";
						pboard[((int)current.location.charAt(0)-65)][x].used = false;
						pboard[((int)current.location.charAt(0)-65)][x].type = 0;
					}
				}
				else{  //orientation == 'V'
					for(int x=((int)current.location.charAt(0)-65);x<((int)current.location.charAt(0)-65)+(current.type + 1);x++){
						pboard[x][((int)current.location.charAt(1)-65)].piece = "___|";
						pboard[x][((int)current.location.charAt(1)-65)].used = false;
						pboard[x][((int)current.location.charAt(1)-65)].type = 0;
					}
				}
			}
			if(layout == 'H'){
				for(int x=((int)locale.charAt(1)-65);x<((int)locale.charAt(1)-65)+(current.type + 1);x++){
					pboard[((int)locale.charAt(0)-65)][x].piece = "_@_|";
					pboard[((int)locale.charAt(0)-65)][x].used = true;
					pboard[((int)locale.charAt(0)-65)][x].type = current.type;
				}
			}
			else{  //layout == 'V'
				for(int x=((int)locale.charAt(0)-65);x<((int)locale.charAt(0)-65)+(current.type + 1);x++){
					pboard[x][((int)locale.charAt(1)-65)].piece = "_@_|";
					pboard[x][((int)locale.charAt(1)-65)].used = true;
					pboard[x][((int)locale.charAt(1)-65)].type = current.type;
				}
			}
			current.placed = true;
			current.location = locale;
			current.orientation = layout;
			printBoard1();
		}
		else
			System.out.println("Invalid Placement. Ships Overlap.");
	}
	
        public void placeBoard2(char layout, ship current, String locale){
		
                boolean overlap = false;
		
		if(layout == 'H'){
			for(int x=((int)locale.charAt(1)-65);x<((int)locale.charAt(1)-65)+(current.type + 1);x++){
				if(eboard[((int)locale.charAt(0)-65)][x].type != current.type &&
				   eboard[((int)locale.charAt(0)-65)][x].used == true)
					overlap = true;
			}
		}
		else{  //layout == 'V'
			for(int x=((int)locale.charAt(0)-65);x<((int)locale.charAt(0)-65)+(current.type + 1);x++){
				if(eboard[x][((int)locale.charAt(1)-65)].type != current.type &&
				   eboard[x][((int)locale.charAt(1)-65)].used == true)
					overlap = true;
			}
		}
		if(!overlap){ //If ships don't overlap
			if(current.placed){
				if(current.orientation == 'H'){
					for(int x=((int)current.location.charAt(1)-65);x<((int)current.location.charAt(1)-65)+(current.type + 1);x++){
						eboard[((int)current.location.charAt(0)-65)][x].piece = "___|";
						eboard[((int)current.location.charAt(0)-65)][x].used = false;
						eboard[((int)current.location.charAt(0)-65)][x].type = 0;
					}
				}
				else{  //orientation == 'V'
					for(int x=((int)current.location.charAt(0)-65);x<((int)current.location.charAt(0)-65)+(current.type + 1);x++){
						eboard[x][((int)current.location.charAt(1)-65)].piece = "___|";
						eboard[x][((int)current.location.charAt(1)-65)].used = false;
						eboard[x][((int)current.location.charAt(1)-65)].type = 0;
					}
				}
			}
			if(layout == 'H'){
				for(int x=((int)locale.charAt(1)-65);x<((int)locale.charAt(1)-65)+(current.type + 1);x++){
					eboard[((int)locale.charAt(0)-65)][x].piece = "_@_|";
					eboard[((int)locale.charAt(0)-65)][x].used = true;
					eboard[((int)locale.charAt(0)-65)][x].type = current.type;
				}
			}
			else{  //layout == 'V'
				for(int x=((int)locale.charAt(0)-65);x<((int)locale.charAt(0)-65)+(current.type + 1);x++){
					eboard[x][((int)locale.charAt(1)-65)].piece = "_@_|";
					eboard[x][((int)locale.charAt(1)-65)].used = true;
					eboard[x][((int)locale.charAt(1)-65)].type = current.type;
				}
			}
			current.placed = true;
			current.location = locale;
			current.orientation = layout;
			printBoard2();
		}
		else
			System.out.println("Invalid Placement. Ships Overlap.");
		
	}

	public void move(String move ){
		
		String valid = "";
		valid = checkMove(move);
                processMove(move);
                //printBoard();
		while(valid != "ok"){
			System.out.println("ERROR: "+ valid);
			move = in.nextLine();
			valid = checkMove(move);
		}
		
		processMove(move);
		
		
		if(count >= 17)
			checkWin();
		
		if(turn == 'X')
			turn = 'O';
		else
			turn = 'X';
	}
	
	public String checkMove(String move){
		
		if(((int)move.charAt(0)-65) >= 15)
			return "Invalid Row. Can only be A-F. Enter another move: ";	
		if(((int)move.charAt(1)-65) >= 15)
			return "Invalid Column. Can only be A-F. Enter another move: ";
		if(turn == 'X'){
			if(eboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].selected)  
				return "Already chosen. Enter another move: ";
		}
		else{
			if(pboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].selected){
		        AI.error = true;
		        AI.himi = 'M';
				return "Bad AI, Bad";
			}
		}
		
		return "ok";
	}
	
	public void processMove(String move){
		
		count++;
		char himi = ' ';
		String message = "";
		
		if(turn == 'X'){
			if(eboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].used){   
				himi = 'X';
				message = "Hit!";
			}
			else{
				himi = 'o';
				message = "Miss!";
			}
			eboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].piece = "_"+himi+"_|";
			eboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].selected = true;
		}
		else{
			if(pboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].used){   
				himi = 'X';
				message = "Hit!";
				AI.himi2 = AI.himi;
				AI.himi = 'H';
				AI.count++;
			}
			else{
				himi = 'o';
				message = "Miss!";
				AI.himi2 = AI.himi;
				AI.himi = 'M';
				AI.count++;
			}
			pboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].piece = "_"+himi+"_|";
			pboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].selected = true;
		}
		
		int counter = 0;
		if(himi == 'X'){
			if(turn == 'X'){
				int stype = eboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].type;
				
				for(int x=0;x<15;x++){
					for(int y=0;y<15;y++){
						if(eboard[x][y].selected && eboard[x][y].type == stype)
							counter++;
					}
				}
				if(counter == (stype + 1)){
					String xship = "";
					if(stype == 1){
						xship = "Submarine!";
						esub.destroyed = true;
					}
					else if(stype == 2){
						xship = "Destroyer!";
						edestroyer.destroyed = true;
					}
					else{
						xship = "Battleship!";
						ebattleship.destroyed = true;
					}
					message += " You destroyed the " + xship;
				}
			}
			else{
				int stype = pboard[((int)move.charAt(0)-65)][((int)move.charAt(1)-65)].type;
				
				for(int x=0;x<15;x++){
					for(int y=0;y<15;y++){
						if(pboard[x][y].selected && pboard[x][y].type == stype)
							counter++;
					}
				}
				if(counter == (stype + 1)){
					String xship = "";
					if(stype == 1){
						xship = "Submarine!";
						sub.destroyed = true;
					}
					else if(stype == 2){
						xship = "Destroyer!";
						destroyer.destroyed = true;
					}
					else{
						xship = "Battleship!";
						battleship.destroyed = true;
					}
					message += " They've destroyed your " + xship;
					AI.himi = 'M';  //Make it choose a random # next time, because ship destroyed
					AI.himi2 = 'M';
				}
			}
		}
		if(turn == 'O')
			message = "Enemy " + message;
		System.out.println(message);
	}
	
	public void checkWin(){  
            if(esub.destroyed && edestroyer.destroyed && ebattleship.destroyed){
                win = true;
                System.out.println("Player 0 wins");
                
            }
            if(sub.destroyed && destroyer.destroyed && battleship.destroyed){
                win = true;
                System.out.println("Player 1 wins");
                
            }
	}
	
	
	
	
	
	
}