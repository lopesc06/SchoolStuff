/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

import java.io.IOException;
import java.net.*;
import java.util.*;

/**
 *
 * @author Arturo Escutia
 */
public class MulticastServer {
    
    private final int MCAST_PORT=9999;
    private final String MCAST_ADDR = "228.1.1.1"; 
    private final int DGRAM_BUF_LEN=512;
    private final ArrayList<Integer> servidores = new ArrayList(Arrays.asList(9999,9998));
    private ArrayList<SEcoHilos>List=new ArrayList();
    
    public static void main(String args[]){
        MulticastServer MS=new MulticastServer();
        MS.connectM();
    }
    
    private void connectM(){
        System.out.println("# servidores:"+servidores.size()+"  "+servidores);
        try {
                String mensajeServer;
                InetAddress gpo=InetAddress.getByName(MCAST_ADDR); 	
                MulticastSocket msocket =new MulticastSocket(MCAST_PORT);
                Iterator itr=servidores.iterator();
                while(itr.hasNext())
                   List.add(new SEcoHilos((Integer)itr.next()));
                msocket.joinGroup(gpo);
                for(;;){
                    itr=servidores.iterator();
                    while(itr.hasNext()){
                        mensajeServer=String.valueOf(itr.next());
                        DatagramPacket packet = new DatagramPacket(mensajeServer.getBytes(),mensajeServer.length(),gpo,MCAST_PORT);
                        msocket.send(packet);
                    }
                }
          } catch(Exception e){
            e.printStackTrace();
        }

    }
    
}
