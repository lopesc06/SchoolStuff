
package battleship;

import java.io.Serializable;

class boardPiece implements Serializable{
		
    public String piece;
    public char player;
    public boolean used;
    public boolean selected;
    public int type;
		
    boardPiece(){
        piece = "___|";
        used = false;
        selected = false;
        type = 0;
    }
}

class AIplay implements Serializable{
    public int lasta;
    public int lastb;
    public int lasta2;
    public int lastb2;
    public char himi;
    public char himi2;
    public int count;
    public boolean error;
		
    AIplay(){
        lasta = 0;
        lastb = 0;
        lasta2 = 0;
        lastb2 = 0;
	himi = 'M';
	himi2 = 'M';
	count = 0;
	error = false;
    }
}

class ship implements Serializable{
    public int type;
    public boolean placed;
    public boolean destroyed;
    public String location;
    public char orientation;
		
    ship(int x){
        type = x;
	placed = false;
	destroyed = false;
	location = "";
	orientation = ' ';
    }
}
	