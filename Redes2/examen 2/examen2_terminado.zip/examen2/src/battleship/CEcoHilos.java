/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

import java.net.*;
import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CEcoHilos {
    
    private final int MCAST_PORT=9999;
    private final String MCAST_ADDR = "228.1.1.1"; 
    private final int DGRAM_BUF_LEN=1024;
    private final Scanner in=new Scanner(System.in);
    public static void main(String[] args){
        CEcoHilos cliente=new CEcoHilos();
        cliente.Connect_Multicast();
    }//main
    
    private void Connect_Multicast(){
        
        try {
                InetAddress gpo=InetAddress.getByName(MCAST_ADDR);
                for(;;){
                    MulticastSocket msocket = new MulticastSocket(MCAST_PORT);
                    msocket.joinGroup(gpo);                
                    byte[] buf = new byte[DGRAM_BUF_LEN]; 
                    DatagramPacket recv = new DatagramPacket(buf,buf.length);
                    msocket.receive(recv);
                    byte [] data = recv.getData();
                    String cadenaRecibida = new String(data).trim();
                    System.out.println(cadenaRecibida);
                    ConnectTCP(Integer.parseInt(cadenaRecibida));
                    System.out.println("Continue?  Y/N");
                    if(in.nextLine().toUpperCase().equals("N"))
                        return;
                    msocket.close();
                }
        } catch (UnknownHostException ex) {
            Logger.getLogger(CEcoHilos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CEcoHilos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    
    private void ConnectTCP(int pto){
        
        try{
            InetAddress srv = InetAddress.getByName("127.0.0.1");
            Socket cl = new Socket(srv,pto);
            System.out.println("Waiting for server ");
            DataInputStream dis = new DataInputStream(cl.getInputStream());
            DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
            int player=dis.readInt();
            System.out.println("Aceptado puerto:"+cl.getPort()+" dirección"+cl.getInetAddress());
            if(player==1)
                System.out.println("Esperando al otro jugador");
            ObjectOutputStream oos= new ObjectOutputStream(cl.getOutputStream());
            ObjectInputStream  ois = new ObjectInputStream(cl.getInputStream()); 
            Battle b=(Battle)ois.readObject();
            
            if(player==0){
                b.printBoard1();
                b.place1();   
            }
            else {
                b.printBoard2();
                b.place2();
                System.out.println("Jugadores Listo");
            }
            oos.writeObject(b);
            while(!b.isWin()){
                 System.out.println("P"+player+" Enter move: ");	
                 dos.writeUTF(in.nextLine());
                 b=(Battle)ois.readObject();
                 if(player==0)
                     b.printBoard1();
                 else
                     b.printBoard2();
            }
            b.checkWin();
            
        
        }catch(Exception e){
            System.out.println("Rechazado");
        }//catch
    } 
    
    
}
