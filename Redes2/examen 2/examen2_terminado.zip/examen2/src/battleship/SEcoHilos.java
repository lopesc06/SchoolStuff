
package battleship;

import java.io.*;
import java.net.*;
import java.util.LinkedList;


public class SEcoHilos implements Runnable {
   
    private int port;
    private LinkedList<Socket> users=new LinkedList(); 
    private LinkedList<Socket> aux=new LinkedList(); 
    Thread hilo;
   /* public static void main(String[] args){
        SEcoHilos S=new SEcoHilos (9995);
        S.Listen();
    }//main
*/

    
    public SEcoHilos(int port) {
        this.port = port;
        hilo=new Thread(this);
        hilo.start();
    }
    
    public void run(){
        try {
            ServerSocket servidor = new ServerSocket(port);
            while(true){
                Socket cliente = servidor.accept();
                for(int i=0;i<aux.size();i++){
                        if(aux.get(i).isClosed())
                            aux.remove(i);
                }
                if(aux.size()<4){
                    users.add(cliente);
                    aux.add(cliente);
                    if(users.size()==2){
                        Manejador m =new Manejador((LinkedList<Socket>)users.clone());
                        m.start();
                        users.clear();
                    }
                }else{
                    cliente.close();
                } 
                    
            }
        } catch (Exception e) {
            e.printStackTrace();
        }   
    }
    
}

class Manejador extends Thread{
    private LinkedList<Socket> users;
    
    public Manejador(LinkedList<Socket> users){
        this.users=users;
    }//constructor
    
    public void run(){
        try{
            DataOutputStream DOS;
            DataInputStream DIS;
            for (int i = 0; i < users.size(); i++) {
                   DOS= new DataOutputStream(users.get(i).getOutputStream());
                   DOS.writeInt(i);
                   DOS.flush();
            }
            
            ObjectOutputStream oos1= new ObjectOutputStream(users.get(0).getOutputStream());
            ObjectOutputStream oos2= new ObjectOutputStream(users.get(1).getOutputStream());
            ObjectInputStream  ois1 = new ObjectInputStream(users.get(0).getInputStream()); 
            ObjectInputStream  ois2 = new ObjectInputStream(users.get(1).getInputStream()); 
            
            System.out.println("En el hilo");
            Battle b=new Battle();
            oos1.writeObject(b);
            b=(Battle)ois1.readObject();
            oos2.writeObject(b);
            b=(Battle)ois2.readObject();
            while(!b.isWin()){
                for (int i = 0; i < users.size(); i++) {
                    DIS=new DataInputStream(users.get(i).getInputStream());
                    b.move(DIS.readUTF());
                }
                oos1.reset();
                oos2.reset();
                oos1.writeObject(b);
                oos2.writeObject(b);
            }
            System.out.println("End of thread");
            oos1.close();
            oos2.close();
            ois1.close();
            ois2.close();
            for (int i = 0; i < users.size(); i++)
                users.get(i).close();
            
        }catch(IOException io){
            for (int i = 0; i < users.size(); i++){
                try { users.get(i).close(); }
                catch (IOException ex) {}
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("S The other player has left the game");
        } 
    }//run
}
