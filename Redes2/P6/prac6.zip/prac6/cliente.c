#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <resolv.h>
#include <unistd.h>
#include <pthread.h>

void *hilo(void *);
void cubeta(int numero);

//elemtos de la estructura 
struct datos
{
	char *ip;
	int pto;
	int *cubeta;
	int elem;
	pthread_mutex_t mutex;
}typedef Cliente;


int main ()
{
	int numeros[3500];
	int i,casilleros;
	int puerto = 1101;
	int hora = time(NULL);
	srand(hora);
	printf("Ingresa el numero de casilleros:\n");
	scanf("%d",&casilleros);
	int inter = 1000 / casilleros;
	int tam[casilleros];
	int j,m,r;
	// se generan los numeros aleatorios 
	for (i = 0; i < 3500; i++)
	{
		numeros[i] = rand()%1000;
	}	
	// se genera el numero de cubetas 
	for (i = 0; i < casilleros; i++)
	{
		tam[i] = 0;
	}
	// se genera el numero de elementos 
	// se crea el tamaño de los arreglos
	for ( j=0 ; j<casilleros; j++)
	{
		for(m=0; m<3500; m++)
		{
			if ( numeros[m] >= (inter*j) && numeros[m] < (inter*(j+1)) ) 
			{
				tam[j]++;
			}
		}
//		printf("Casillero: [%d] --> %d\n",(inter*j),tam[j] );
	}

	// se declara el numero de arreglos con el tamaño
	int *a [casilleros]; 
	for (i = 0; i < casilleros ; i++)
	{
		a[i] = (int *)malloc(sizeof(int)*tam[i]);
	}
	Cliente cl[casilleros];
	printf("*********************\n");	
	//se inicializan los arreglos 
	for (i = 0; i < casilleros ; i++)
	{
		for (j = 0; j<tam[j] ; j++)
		{
			a[i][j]=0;
		}
	}
	// se almacenan los numeros en su cubeta correspondiente 
	for ( j=0 ; j<casilleros; j++)
	{
		r=0;
		for(m=0; m<3500; m++)
		{
			if ( numeros[m] >= (inter*j) && numeros[m] < (inter*(j+1)) && r<tam[j]) 
			{
				a[j][r] = numeros[m]; // ya estan separados los elementos por cubeta 
	//			printf("Elementos: [%d]\n",a[j][r]);
				r++;
			}
		}
	}
	for (i = 0; i < casilleros ; i++)
	{
		cl[i].ip = "127.0.0.1"; //se asigna la ip a la cubeta correspondiente 
 		cl[i].pto = 1101;//asigna el puerto a la cubeta correspondiente se incrementa el numero de puerto 
		cl[i].cubeta = a[i]; // se envia los datos que le corresponden a cada cubeta
		cl[i].elem = tam[i];//se envia el tamaño de cada cubeta 
		// se inicializa la variable de tipo mutex
		pthread_mutex_init(&cl[i].mutex,NULL);
		
	}	
	// se crean los hilos correspondientes 
	pthread_t thread[casilleros];
	printf("\n Iniciando proceso\n");
	// se inician los hilos con la informacion de cada cubeta
	for (i = 0; i <casilleros ; i++)
	{
		pthread_create(&thread[i],NULL,hilo,&(cl[i]));
	}
	// esperamos a que cada hilo trabaje
	for (i = 0; i <casilleros ; i++)
	{
		pthread_join(thread[i],NULL);
	}
	// se asigna el arrelgo ya ordenado 
	int temp = 0;
	for (i = 0; i < casilleros ; i++)
	{
		for (j = 0; j<tam[i] ; j++)
		{
			numeros[temp] = a[i][j];
			temp++;
		}
	}
	// se imprime el arreglo 
	printf("\nArreglo ordenado recibido.\n");
	for (i = 0; i <3500 ; i++)
	{
		printf("(%d) ---> %d \n",i,numeros[i] );
	}
	printf("----------------->  Terminado  <--------------------\n");
	return 0;
}

void *hilo(void *datos)
{
	//Se capura la escrucutra de datos del cliente.
	Cliente *cl=(Cliente *)datos;
	// se accede al mutex
	pthread_mutex_lock(&cl->mutex);		
	//Se inicializan los valores de la estructura 
	int* cub = cl->cubeta;
	int elementos = cl->elem;
	int host_port = cl->pto;
	char* host_name = cl->ip;
	printf("\nHilo con puerto: %d\n",host_port);
	//Se inicializan valores que se ocuparan mas adelante....
	struct sockaddr_in my_addr;
//	int *buffer;
	int bytecount;
	int buffer_len = 0;
	int hsock;
	int * p_int;
	int err,i;
	//Se crea el socket del cliente...
	hsock = socket(AF_INET, SOCK_STREAM, 0);
	if(hsock == -1)
	{
		printf("Error initializing socket %d\n",errno);
		exit(0);
	}
	p_int = (int*)malloc(sizeof(int));
	*p_int = 1;
	if( (setsockopt(hsock, SOL_SOCKET, SO_REUSEADDR, (char*)p_int, sizeof(int)) == -1 )||
	    (setsockopt(hsock, SOL_SOCKET, SO_KEEPALIVE, (char*)p_int, sizeof(int)) == -1 ) )
	{
		printf("Error setting options %d\n",errno);
		free(p_int);
		exit(0);
	}
	free(p_int);
	// se asignan los valores de la estructura del socket
	my_addr.sin_family = AF_INET ;
	my_addr.sin_port = htons(host_port);
	memset(&(my_addr.sin_zero), 0, 8);
	my_addr.sin_addr.s_addr = inet_addr(host_name);
	//Se conecta el cliente al servidor...
	if( connect( hsock, (struct sockaddr*)&my_addr, sizeof(my_addr)) == -1 )
	{
		if((err = errno) != EINPROGRESS)
		{
			fprintf(stderr, "Error connecting socket %d\n", errno);
			exit(0);
		}
	}
	// se envia la cubeta a servidor 
	if( (bytecount=send(hsock, cub,elementos*4,0))== -1)
	{
		fprintf(stderr, "Error sending data %d\n", errno);
		exit(0);
	}
	// se resive la cubeta ya ordenada del servidor 
	if((bytecount = recv(hsock, cub, elementos*4, 0))== -1)
	{
		fprintf(stderr, "Error receiving data %d\n", errno);
		exit(0);
	}
	//Cierra socket.
	close(hsock);
}
